package com.example.trial;

import java.util.Map;

public class ResponseModel {

    private Map<String, Object> response;

    public ResponseModel(Map<String, Object> response){
        this.response=response;
    }

    public Map<String, Object> getResponse() {
        return response;
    }

    public void setResponse(Map<String, Object> response) {
        this.response = response;
    }
}
