package com.example.trial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    String url = "http://demo6.maxwellserver.com/clients/androidtesting/addstudents.php?";
    Logger logger = LoggerFactory.getLogger(MainActivity.class);

    private EditText id,first_name,last_name, dateofbirth,gender,section,standard,email, mobileno, regdatetime;
    private Button postDataBtn;
    private TextView responseTV;
    private ProgressBar loadingPB;
    RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing our views
        logger.debug("oncreate");
        id=(EditText) findViewById(R.id.edit10);
        first_name=(EditText) findViewById(R.id.edit1);
        last_name=(EditText) findViewById(R.id.edit2);
        dateofbirth =(EditText) findViewById(R.id.edit3);
        gender=(EditText) findViewById(R.id.edit4);
        section=(EditText) findViewById(R.id.edit5);
        standard=(EditText) findViewById(R.id.edit6);
        email=(EditText) findViewById(R.id.edit7);
        mobileno =(EditText) findViewById(R.id.edit8);
        regdatetime =(EditText) findViewById(R.id.edit9);
        postDataBtn=(Button) findViewById(R.id.b1);
        responseTV=(TextView) findViewById(R.id.idTVResponse);
        loadingPB=(ProgressBar) findViewById(R.id.idLoadingPB);
        logger.debug("button click");
        requestQueue= Volley.newRequestQueue(getApplicationContext());
        //add on click lister on our button
        postDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logger.debug("button click");
                if (id.getText().toString().isEmpty() && first_name.getText().toString().isEmpty()&& last_name.getText().toString().isEmpty()
                        && dateofbirth.getText().toString().isEmpty()&& gender.getText().toString().isEmpty()&& section.getText().toString().isEmpty()
                        && standard.getText().toString().isEmpty()&& email.getText().toString().isEmpty()&& mobileno.getText().toString().isEmpty()&& regdatetime.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter all columns", Toast.LENGTH_SHORT).show();
                    return;
                }
                postData(id.getText().toString(),first_name.getText().toString(),last_name.getText().toString(),
                        dateofbirth.getText().toString(),gender.getText().toString(),section.getText().toString(),
                        standard.getText().toString(),email.getText().toString(), mobileno.getText().toString(),
                        regdatetime.getText().toString());
            }
        });

    }
    private void postData(String eid,String efname,String elname,String eDob,String egender,String eSection,String eStandard,String eEmail,String emobileno,String eRegdateTime){
        //display our progress bar
        loadingPB.setVisibility(View.VISIBLE);

        //Retrofit retrofit =new Retrofit.Builder().baseUrl()
        //built and passing our base url


        RequestQueue queue =Volley.newRequestQueue(MainActivity.this);

        StringRequest request = new StringRequest(Request.Method.POST,url, response -> {
            loadingPB.setVisibility(View.GONE);

            id.setText(" ");
            first_name.setText("");
            last_name.setText("");
            dateofbirth.setText("");
            gender.setText("");
            section.setText("");
            standard.setText(" ");
            email.setText(" ");
            mobileno.setText(" ");
            regdatetime.setText("");

            // on below line we are displaying a success toast message.
            Toast.makeText(MainActivity.this, "Data added to API", Toast.LENGTH_SHORT).show();
            try {
                // on below line we are parsing the response
                // to json object to extract data from it.
                JSONObject respObj = new JSONObject(response);

                // below are the strings which we
                // extract from our json object.
                String sid= respObj.getString("id");
                String sfirst= respObj.getString("first_name");
                String slast= respObj.getString("last_name");
                String sdob= respObj.getString("dob");
                String sgender= respObj.getString("gender");
                String sSection= respObj.getString("section");
                String sStandard= respObj.getString("standard");
                String semail= respObj.getString("email");
                String sMobileno= respObj.getString("mobileNo");
                String sregDateTime= respObj.getString("regDateTime");



                // on below line we are setting this string s to our text view.
                responseTV.setText("id:"+sid +"Name : " + sfirst + " " + "lastname : " + slast+" "+"dob:"+
                        sdob+" "+"gender:"+sgender+" "+"section:"+sSection+" "+"standard:"+sStandard+" "+
                        "mail:"+semail+" "+"mobileno:"+sMobileno+" "+"regdatatime:"+sregDateTime);
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this,"fail to get response"+error,Toast.LENGTH_LONG).show();
            }

        }){
            @Override
            protected Map<String, String> getParams() {
                // below line we are creating a map for
                // storing our values in key and value pair.
                Map<String, String> params = new HashMap<>();


                // on below line we are passing our key
                // and value pair to our parameters.
                params.put("id",eid );
                params.put("first_name",efname );
                params.put("last_name",elname );
                params.put("dateofbirth",eDob );
                params.put("gender", egender);
                params.put("section", eSection);
                params.put("standard",eStandard );
                params.put("email", eEmail);
                params.put("mobileno",emobileno);
                params.put("regdatetime", eRegdateTime);


                // at last we are
                // returning our params.
                return params;
            }
        };
        // below line is to make
        // a json object request.
        queue.add(request);
    }
}

      /*  JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET,
                        url,
                        null,
                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {
                                logger.debug( "Response: " + response.toString());
                                responseTV.setText("Response: " + response.toString());

                            }
                        },
                        new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // TODO: Handle error
                                error.printStackTrace();

                            }
                        });
       requestQueue.add( jsonObjectRequest);
    }
}*/