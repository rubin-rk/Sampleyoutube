package com.example.trial;

public class DataModal {
    private String id;
    private String first_name;
    private String last_name;
    private String dateofbirth;
    private String gender;
    private String section;
    private String standard;
    private String email;
    private String mobileno;
    private String regdatetime;

    public DataModal(String eid, String efname, String elname, String eDob, String egender, String eSection, String eStandard, String eEmail, String emobileno, String eRegdateTime) {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getRegdatetime() {
        return regdatetime;
    }

    public void setRegdatetime(String regdatetime) {
        this.regdatetime = regdatetime;
    }
}
